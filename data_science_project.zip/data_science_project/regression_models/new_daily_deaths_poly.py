# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('covid_dataset_india.csv')
x = dataset.iloc[:, [0]].values
y = dataset.iloc[:, [4]].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)

# Fitting Linear Regression to the dataset
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(x, y)

# Fitting Polynomial Regression to the dataset
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree = 5)
x_poly = poly_reg.fit_transform(x)
poly_reg.fit(x_poly, y)
lin_reg_2 = LinearRegression()
lin_reg_2.fit(x_poly, y)

# Visualising the Linear Regression results
plt.scatter(x, y, color = 'red')
plt.plot(x, lin_reg.predict(x), color = 'blue')
plt.title('Covid 19 in india')
plt.xlabel('Day')
plt.ylabel('number of new deaths per day')
plt.show()

# Visualising the Polynomial Regression results
plt.scatter(x, y, color = 'red')
plt.plot(x, lin_reg_2.predict(poly_reg.fit_transform(x)), color = 'blue')
plt.title('Covid 19 in india')
plt.xlabel('Day')
plt.ylabel('number of new deaths per day')
plt.show()

# Predicting a new result with Linear Regression
lin_reg.predict([[130]])

# Predicting a new result with Polynomial Regression
lin_reg_2.predict(poly_reg.fit_transform([[127]]))

y_pred=lin_reg_2.predict(poly_reg.fit_transform(x_test))
from sklearn.metrics import r2_score
r2_score(y_test, y_pred)

#r2 score=0.98521698
