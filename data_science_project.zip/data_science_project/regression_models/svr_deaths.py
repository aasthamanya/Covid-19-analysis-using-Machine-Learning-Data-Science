# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('covid_dataset_india.csv')
x = dataset.iloc[:, [0]].values
y = dataset.iloc[:, [4]].values

#splitting the data into training set and test set
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)

#feature scaling
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
sc_y = StandardScaler()
x_train = sc_X.fit_transform(x_train)
x_test = sc_X.fit_transform(x_test)


# Fitting SVR to the dataset
from sklearn.svm import SVR
regressor = SVR(kernel = 'rbf')
regressor.fit(x_train, y_train)

#predicting the test set results
y_pred = regressor.predict(x_test)

# Visualising the Decision Tree Regression results (higher resolution)
X_grid = np.arange(min(x), max(x), 0.01)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(x, y, color = 'red')
plt.plot(X_grid, regressor.predict(X_grid), color = 'blue')
plt.title('Covid-19 in India (SVR)')
plt.xlabel('Day')
plt.ylabel('Number of new deaths per day')
plt.show()

#evaluation score
from sklearn.metrics import r2_score
r2_score(y_test, y_pred)

#r2score = 0.911354