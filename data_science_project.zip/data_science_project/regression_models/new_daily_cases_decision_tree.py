# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('covid_dataset_india.csv')
x = dataset.iloc[:, [0]].values
y = dataset.iloc[:, [2]].values

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 0)

from sklearn.tree import DecisionTreeRegressor
regressor = DecisionTreeRegressor(random_state = 0)
regressor.fit(x_train, y_train)

#predicting the test set results
y_pred = regressor.predict(x_test)

# Visualising the Decision Tree Regression results (higher resolution)
X_grid = np.arange(min(x), max(x), 0.01)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(x, y, color = 'red')
plt.plot(X_grid, regressor.predict(X_grid), color = 'blue')
plt.title('Covid-19 in India (Decision Tree Regression)')
plt.xlabel('Day')
plt.ylabel('Number of new cases per day')
plt.show()

#evaluation score
from sklearn.metrics import r2_score
r2_score(y_test, y_pred)

#r2score = 0.911354